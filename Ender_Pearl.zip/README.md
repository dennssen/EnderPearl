# Ender Pearl
Version 1.0.2, uploaded by Lakatrazz into category item
Original File Name: EnderPearlbyLakatrazz.zip

Fully functional Ender Pearl from Minecraft! (You've probably heard of it.)
## Features
- Ender Pearl
- Throw Sound
- Hit Sound
- Teleportation
## Requires
- ModThatIsNotMod (For Grow Pools/Spawning Infinite Pearls)

## Changelog

v1.0.2: Fixed:
- Fixed teleporting out of the map on level load when low framerate, changed pool of teleporter object to 1 so the 1 second delay only happens once
v1.0.1: Fixed:
- Hopefully fixed the issue some people were having where they were teleported out of bounds on level load (First few ender pearls may have a slightly delayed teleport since it was activating when pooled)